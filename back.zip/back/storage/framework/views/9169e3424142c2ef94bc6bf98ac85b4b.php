<?php $__env->startSection('page-style'); ?>
<style>
    .form-container {
        max-width: 600px;
        margin: 0 auto;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        font-weight: bold;
    }
    .form-control {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
    }
    .btn {
        margin-top: 10px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container form-container">
    <h1>Crear Nueva Subcategoría</h1>

    <!-- Mostrar errores de validación -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Formulario para crear una nueva subcategoría -->
    <form action="<?php echo e(route('subcategory.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Campo para el nombre de la subcategoría -->
        <div class="form-group">
            <label for="name">Nombre de la Subcategoría</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <!-- Campo para el ID de la categoría -->
        <div class="form-group">
            <label for="idCategory">ID de la Categoría</label>
            <input type="number" id="idCategory" name="idCategory" class="form-control" value="<?php echo e(old('idCategory')); ?>" required>
        </div>

        <!-- Botón para enviar el formulario -->
        <button type="submit" class="btn btn-success">Crear Subcategoría</button>
        <a href="<?php echo e(route('subcategory.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
// Puedes agregar scripts aquí si los necesitas
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mati/Escritorio/transversal-tr1-2024-2025-daw_24_25_tr1g7/back/resources/views/SubCategorias/create.blade.php ENDPATH**/ ?>