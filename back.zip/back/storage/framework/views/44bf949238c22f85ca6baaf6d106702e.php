<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Lista de Marcas</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('brand.create')); ?>" class="btn btn-primary mb-3">Crear Nueva Marca</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Slug</th>
                <th>URL</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($brand->id); ?></td>
                    <td><?php echo e($brand->name); ?></td>
                    <td><?php echo e($brand->slug); ?></td>
                    <td>
                        <?php if($brand->url): ?>
                            <a href="<?php echo e($brand->url); ?>" target="_blank"><?php echo e($brand->url); ?></a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($brand->image): ?>
                            <img src="<?php echo e(asset('storage/' . $brand->image)); ?>" alt="<?php echo e($brand->name); ?>" width="50">
                        <?php else: ?>
                            Sin imagen
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('brand.edit', $brand->id)); ?>" class="btn btn-warning btn-sm">Editar</a>

                        <form action="<?php echo e(route('brand.delete', $brand->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar esta marca?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No hay marcas disponibles.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mati/Escritorio/transversal-tr1-2024-2025-daw_24_25_tr1g7/back/resources/views/brand/index.blade.php ENDPATH**/ ?>