<?php $__env->startSection('page-style'); ?>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .btn-edit {
            color:white;
            background-color:#e0a800;
        }
        .action-buttons {
            display: flex; 
            gap: 10px; 
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Lista de Productos</h1>

        <form method="GET" action="<?php echo e(route('producte.index')); ?>">
            <div class="input-group mb-3">
                <input type="text" name="query" class="form-control" placeholder="Nom del producte" value="<?php echo e(request()->input('query')); ?>">
                <button class="btn btn-outline-secondary" type="submit">Buscar</button>
            </div>
        </form>
        <a href="<?php echo e(route('producte.crear')); ?>" class="btn btn-success">Afegir Producte</a><br><br>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Stock</th>
                    <th>Marca</th>
                    <th>Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $producte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id="<?php echo e($producto->id); ?>">
                        <td><?php echo e($producto->id); ?></td>
                        <td><?php echo e($producto->name); ?></td>
                        <td><?php echo e($producto->description); ?></td>
                        <td><?php echo e($producto->stock); ?></td>
                        <td><?php echo e($producto->brand->name ?? 'Sin Marca'); ?></td>
                        <td><?php echo e($producto->price); ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('producte.edit', $producto->id)); ?>" class="btn btn-edit">Editar</a>
                                <button onclick="deleteProduct(<?php echo e($producto->id); ?>)" class="btn btn-danger">Eliminar</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
    function deleteProduct(id) {
        if (confirm('¿Estas segur de que vols eliminar aquest producte?')) {
            fetch(`/productedelete/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'successful') {
                    const row = document.querySelector(`tr[data-id="${id}"]`);
                    row.remove();
                } else {
                    alert('Error al eliminar el producto: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Hubo un problema con la petición fetch:', error);
                alert('Ocurrió un error al intentar eliminar el producto.');
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mati/Escritorio/transversal-tr1-2024-2025-daw_24_25_tr1g7/back/resources/views/Products/index.blade.php ENDPATH**/ ?>